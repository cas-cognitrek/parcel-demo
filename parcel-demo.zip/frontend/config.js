// If you deploy the backend API on Render, set API_BASE like:
window.API_BASE = "https://parcel-demo-backend.onrender.com";
// For local/static only, leave blank:
// window.API_BASE = "";
